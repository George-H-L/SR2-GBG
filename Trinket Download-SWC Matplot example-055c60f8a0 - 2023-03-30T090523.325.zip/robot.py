import time
import math
from sr.robot3 import *
import cv2
import numpy as np
R = Robot()
Servo_1 = R.servo_board.servos[1]
Servo_2 = R.servo_board.servos[2]
#SR0KFF is the wheels board
#SR0WH1J is the claw board
motorL_2 = R.motor_boards["SR0TBG"].motors[0]
motorR_2 = R.motor_boards["SR0TBG"].motors[1]
#motorLeft is left wheel, motorRight is right wheel 
motorL_1 = R.motor_boards["SR0GJ1B"].motors[0]
motorR_1 = R.motor_boards["SR0GJ1B"].motors[1]
#motorClaw is claw, motorVert is vertical movement of claw
def Filter():
    R.camera.save(R.usbkey / "initial-view.png")
    img = cv2.imread( "initial-view.png")
    # It converts the BGR color space of image to HSV color space
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
      
    # Threshold of gold in HSV space
    lower_gold = np.array([10, 50, 20])
    upper_gold = np.array([30, 255, 255])
  
    # preparing the mask to overlay
    mask = cv2.inRange(hsv, lower_gold, upper_gold)
    
    cv2.imwrite(str(R.usbkey / 'Result.png'), mask)

def box():
  Filter()
  image = cv2.imread("Result.png")
  original_image= image

  gray= cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)

  edges= cv2.Canny(gray, 50,200)

  contours, hierarchy= cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

  def get_contour_areas(contours):

    all_areas= []

    for cnt in contours:
        area= cv2.contourArea(cnt)
        all_areas.append(area)

    return all_areas


  sorted_contours= sorted(contours, key=cv2.contourArea, reverse= True)
  largest_item= sorted_contours[0]
  cv2.drawContours(original_image, largest_item, -1, (255,0,0),10)
  cv2.imwrite(str(R.usbkey / 'ResulLargest.png'), original_image)

vertex0 = list(range(28))
vertex1 = list(range(7, 28)) + list(range(7))
vertex2 = list(range(14, 28)) + list(range(14))
vertex3 = list(range(21, 28)) + list(range(21))

wallmarkers = vertex0

def drv(p, t):
  motorL_1.power = -p
  motorR_1.power = p
  motorL_2.power = -p
  motorR_2.power = p
  time.sleep(t)
  motorL_1.power = COAST                                              
  motorR_1.power = COAST
  motorL_2.power = COAST
  motorR_2.power = COAST
  time.sleep(3)

def turn(p, t):
  motorL_1.power = p
  motorR_1.power = p
  motorL_2.power = p
  motorR_2.power = p
  time.sleep(t)
  motorL_1.power = BRAKE
  motorR_1.power = BRAKE
  motorL_2.power = BRAKE
  motorR_2.power = BRAKE

def returnDistance(marker):
  return marker.distance

def isItCube(marker):
  return marker.id == 73

drv(0.3, 1.6)
turn(-0.4, 1.8)
time.sleep(1)
box()
while True:
  picture = R.camera.see()
  print(picture)
  picture = list(filter(isItCube, picture))
  print(picture)
  picture.sort(key = returnDistance)
  print(picture)


  while len(picture) == 0:
    drv(0.5, 0.5)
    picture = R.camera.see()
    print(picture)
    picture = list(filter(isItCube, picture))
    print(picture)
    picture.sort(key = returnDistance)
    print(picture)

  if picture[0].cartesian.y < 0:
    while picture[0].cartesian.y < 0:
      turn(0.5, 0.2)
      time.sleep(0.5)
      pictureTemp = R.camera.see()
      print(pictureTemp)
      pictureTemp = list(filter(isItCube, pictureTemp))
      print(pictureTemp)
      pictureTemp.sort(key = returnDistance)
      print(pictureTemp)
      if len(pictureTemp) > 0:
        picture = pictureTemp
        del pictureTemp
      time.sleep(0.5)
  elif picture[0].cartesian.y > 0:
    while picture[0].cartesian.y > 0:
      turn(-0.5, 0.2)
      time.sleep(0.5)
      pictureTemp = R.camera.see()
      print(pictureTemp)
      pictureTemp = list(filter(isItCube, pictureTemp))
      print(pictureTemp)
      pictureTemp.sort(key = returnDistance)
      print(pictureTemp)
      if len(pictureTemp) > 0:
        picture = pictureTemp
        del pictureTemp
      time.sleep(0.5)

  drv(0.3, 1.2)
